const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const multer = require('multer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT || 4000);
const ROOT = path.resolve(__dirname, '..');
const CLIENT_DIST = path.join(ROOT, 'dist');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.post('/api/payments/webhook', express.raw({type:'application/json'}), async (req,res)=>{
  const secret=getSecret('PAYSTACK_SECRET_KEY');
  const signature=req.get('x-paystack-signature')||'';
  const expected=secret?crypto.createHmac('sha512',secret).update(req.body).digest('hex'):'';
  if(!secret || !signature || signature.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.status(401).send('Invalid signature');
  let event; try{event=JSON.parse(req.body.toString('utf8'))}catch{return res.status(400).send('Bad payload')}
  if(event.event==='charge.success'){
    const data=event.data||{};
    const order=db.prepare('SELECT * FROM orders WHERE reference=? OR paystack_reference=?').get(data.reference,data.reference);
    if(order && Number(data.amount)===order.total*100) db.prepare("UPDATE orders SET payment_status='Paid',order_status=CASE WHEN order_status='Pending' THEN 'Paid' ELSE order_status END,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
  }
  res.sendStatus(200);
});
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));

const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  price INTEGER NOT NULL,
  category TEXT NOT NULL DEFAULT 'Jewellery',
  image_url TEXT NOT NULL DEFAULT '',
  stock INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reference TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  currency TEXT NOT NULL DEFAULT 'NGN',
  total INTEGER NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'Pending',
  order_status TEXT NOT NULL DEFAULT 'Pending',
  paystack_reference TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  quantity INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unread',
  reply TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  replied_at TEXT
);
CREATE TABLE IF NOT EXISTS media (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL,
  url TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS secrets (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS oauth_connections (
  provider TEXT PRIMARY KEY,
  account_name TEXT NOT NULL DEFAULT '',
  external_id TEXT NOT NULL DEFAULT '',
  access_token TEXT NOT NULL DEFAULT '',
  refresh_token TEXT NOT NULL DEFAULT '',
  expires_at TEXT,
  meta_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function seed() {
  const admin = db.prepare('SELECT id FROM admins LIMIT 1').get();
  if (!admin) {
    const password = process.env.ADMIN_BOOTSTRAP_PASSWORD || 'change-me';
    const hash = bcrypt.hashSync(password, 12);
    db.prepare('INSERT INTO admins(email,password_hash) VALUES(?,?)').run('admin@furbzsparkle.com', hash);
    console.log('Bootstrap admin: admin@furbzsparkle.com');
    if (!process.env.ADMIN_BOOTSTRAP_PASSWORD) console.warn('Set ADMIN_BOOTSTRAP_PASSWORD before production.');
  }
  const count = db.prepare('SELECT COUNT(*) c FROM products').get().c;
  if (!count) {
    const products = [
      ['Gold Twist Band Ring','gold-twist-band-ring','A polished statement ring with a sculptural twist.',12500,'Rings','/assets/product-ring.jpg',8],
      ['Gold Chain Layered Necklace','gold-chain-layered-necklace','A layered gold-tone necklace designed for everyday sparkle.',9500,'Necklaces','/assets/product-ring.jpg',12],
      ['Crystal Stud Earrings','crystal-stud-earrings','Elegant crystal studs for a clean, luminous finish.',15000,'Earrings','/assets/product-ring.jpg',10],
      ['Sapphire Filigree Ring','sapphire-filigree-ring','A deep blue sapphire-inspired centerpiece with delicate detailing.',18500,'Rings','/assets/product-sapphire.jpg',5],
      ['Crystal Cluster Ring','crystal-cluster-ring','A clustered crystal ring made to catch the light.',17000,'Rings','/assets/product-sapphire.jpg',7]
    ];
    const stmt = db.prepare('INSERT INTO products(name,slug,description,price,category,image_url,stock) VALUES(?,?,?,?,?,?,?)');
    const tx = db.transaction(rows => rows.forEach(r => stmt.run(...r)));
    tx(products);
  }
  const defaults = {
    whatsapp:'', instagram:'', tiktok:'', facebook:'', pinterest:'', email:'',
    hero_title:'Shop by Category', hero_eyebrow:'COLLECTIONS', founder_title:'Made by hand. Made with heart.',
    founder_text:'Every Furbz Sparkle piece begins as a sketch and ends as something you will wear for a lifetime. We believe jewellery should carry meaning — not just beauty.',
    announcement:'Every piece is handcrafted with intention — made to be worn, treasured, and passed on.'
  };
  const stmt = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
  Object.entries(defaults).forEach(([k,v])=>stmt.run(k,v));
}
seed();

const upload = multer({
  storage: multer.diskStorage({ destination: UPLOAD_DIR, filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, crypto.randomUUID() + ext);
  }}),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif|avif)$/.test(file.mimetype))
});

function publicSettings() {
  return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]));
}
function encryptionKey(){
  const raw=process.env.APP_ENCRYPTION_KEY;
  if(!raw && process.env.NODE_ENV==='production') throw new Error('APP_ENCRYPTION_KEY is required in production');
  return crypto.createHash('sha256').update(raw || 'dev-only-change-me').digest();
}
function encryptSecret(value){
  const iv=crypto.randomBytes(12); const cipher=crypto.createCipheriv('aes-256-gcm',encryptionKey(),iv);
  const encrypted=Buffer.concat([cipher.update(String(value),'utf8'),cipher.final()]);
  return Buffer.concat([iv,cipher.getAuthTag(),encrypted]).toString('base64');
}
function decryptSecret(value){
  try{const b=Buffer.from(value,'base64');const iv=b.subarray(0,12),tag=b.subarray(12,28),data=b.subarray(28);const decipher=crypto.createDecipheriv('aes-256-gcm',encryptionKey(),iv);decipher.setAuthTag(tag);return Buffer.concat([decipher.update(data),decipher.final()]).toString('utf8')}catch{return ''}
}
function getSecret(key) {
  const env = process.env[key];
  if (env) return env;
  const row = db.prepare('SELECT value FROM secrets WHERE key=?').get(key);
  return row?.value ? decryptSecret(row.value) : '';
}
function setSecret(key, value) { db.prepare('INSERT INTO secrets(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, encryptSecret(value)); }
function tokenFor(admin) { return jwt.sign({ sub: admin.id, email: admin.email, role:'admin' }, process.env.JWT_SECRET || 'dev-only-change-me', { expiresIn:'8h' }); }
function auth(req,res,next) {
  const raw = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : req.cookies?.admin_token;
  const token = raw;
  if (!token) return res.status(401).json({error:'Authentication required'});
  try { req.admin = jwt.verify(token, process.env.JWT_SECRET || 'dev-only-change-me'); next(); }
  catch { return res.status(401).json({error:'Session expired. Please sign in again.'}); }
}
function originGuard(req,res,next) {
  if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return next();
  const origin = req.get('origin');
  const allowed = [process.env.CLIENT_URL, process.env.APP_URL].filter(Boolean);
  if (origin && allowed.length && !allowed.includes(origin)) return res.status(403).json({error:'Request origin not allowed'});
  next();
}
function slugify(s){return s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') || crypto.randomUUID();}
function money(n){return Number(n||0);}
function safeError(res, status=500){return res.status(status).json({error:'Something went wrong. Please try again.'});}

app.get('/api/store', (req,res)=>{
  const products = db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all();
  res.json({products, settings: publicSettings(), currency: process.env.PAYSTACK_CURRENCY || 'NGN', paystackPublicKey: process.env.PAYSTACK_PUBLIC_KEY || ''});
});

app.post('/api/auth/login', rateLimit({windowMs:15*60*1000,max:10}), async (req,res)=>{
  try {
    const {email,password}=req.body||{};
    const admin=db.prepare('SELECT * FROM admins WHERE lower(email)=lower(?)').get(String(email||''));
    if (!admin || !(await bcrypt.compare(String(password||''),admin.password_hash))) return res.status(401).json({error:'Invalid email or password'});
    res.json({token:tokenFor(admin), admin:{id:admin.id,email:admin.email}});
  } catch { safeError(res); }
});
app.get('/api/auth/me', auth, (req,res)=>res.json({admin:{id:req.admin.sub,email:req.admin.email}}));
app.post('/api/auth/change-password', auth, async (req,res)=>{
  const {currentPassword,newPassword}=req.body||{};
  const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.sub);
  if (!admin || !(await bcrypt.compare(String(currentPassword||''),admin.password_hash))) return res.status(400).json({error:'Current password is incorrect'});
  if (!newPassword || String(newPassword).length < 12) return res.status(400).json({error:'New password must be at least 12 characters'});
  db.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(await bcrypt.hash(String(newPassword),12),admin.id);
  res.json({ok:true});
});

app.get('/api/products', (req,res)=>res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()));
app.post('/api/products', auth, originGuard, (req,res)=>{
  try {
    const {name,description,price,category,image_url,stock,active}=req.body;
    if(!name || !Number.isFinite(Number(price))) return res.status(400).json({error:'Product name and valid price are required'});
    const slug=slugify(name)+'-'+crypto.randomBytes(3).toString('hex');
    const r=db.prepare('INSERT INTO products(name,slug,description,price,category,image_url,stock,active,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').run(name,description||'',money(price),category||'Jewellery',image_url||'',Number(stock||0),active===false?0:1);
    res.json(db.prepare('SELECT * FROM products WHERE id=?').get(r.lastInsertRowid));
  } catch { safeError(res); }
});
app.put('/api/products/:id', auth, originGuard, (req,res)=>{
  try {
    const {name,description,price,category,image_url,stock,active}=req.body;
    if(!name || !Number.isFinite(Number(price))) return res.status(400).json({error:'Product name and valid price are required'});
    db.prepare('UPDATE products SET name=?,description=?,price=?,category=?,image_url=?,stock=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name,description||'',money(price),category||'Jewellery',image_url||'',Number(stock||0),active?1:0,req.params.id);
    res.json(db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id));
  } catch { safeError(res); }
});
app.delete('/api/products/:id', auth, originGuard, (req,res)=>{db.prepare('UPDATE products SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(req.params.id);res.json({ok:true});});

app.post('/api/media', auth, originGuard, upload.single('file'), (req,res)=>{
  if(!req.file) return res.status(400).json({error:'Please upload an image file'});
  const url='/uploads/'+req.file.filename;
  const r=db.prepare('INSERT INTO media(filename,url,mime_type) VALUES(?,?,?)').run(req.file.originalname,url,req.file.mimetype);
  res.json({id:r.lastInsertRowid,filename:req.file.originalname,url,mime_type:req.file.mimetype});
});
app.get('/api/media', auth, (req,res)=>res.json(db.prepare('SELECT * FROM media ORDER BY id DESC').all()));
app.delete('/api/media/:id', auth, originGuard, (req,res)=>{
  const row=db.prepare('SELECT * FROM media WHERE id=?').get(req.params.id);
  if(row){try{fs.unlinkSync(path.join(UPLOAD_DIR,path.basename(row.url)))}catch{} db.prepare('DELETE FROM media WHERE id=?').run(req.params.id);}
  res.json({ok:true});
});

app.post('/api/orders', originGuard, (req,res)=>{
  try {
    const {customer,items,notes}=req.body||{};
    if(!customer?.firstName || !customer?.lastName || !customer?.email || !Array.isArray(items) || !items.length) return res.status(400).json({error:'Complete customer details and cart items are required'});
    const ids=items.map(x=>Number(x.productId));
    const products=db.prepare(`SELECT * FROM products WHERE id IN (${ids.map(()=>'?').join(',')}) AND active=1`).all(...ids);
    const byId=new Map(products.map(p=>[p.id,p]));
    let total=0; const normalized=[];
    for(const item of items){const p=byId.get(Number(item.productId)); const qty=Math.max(1,Math.min(20,Number(item.quantity)||1)); if(!p || p.stock<qty) return res.status(400).json({error:`${p?.name||'A product'} is unavailable or out of stock`}); total+=p.price*qty; normalized.push({p,qty});}
    const reference='FURBZ-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex');
    const tx=db.transaction(()=>{
      const order=db.prepare('INSERT INTO orders(reference,customer_name,email,phone,address,notes,currency,total) VALUES(?,?,?,?,?,?,?,?)').run(reference,`${customer.firstName} ${customer.lastName}`,customer.email,customer.phone||'',customer.address||'',notes||'',process.env.PAYSTACK_CURRENCY||'NGN',total);
      const itemStmt=db.prepare('INSERT INTO order_items(order_id,product_id,name,price,quantity) VALUES(?,?,?,?,?)');
      normalized.forEach(({p,qty})=>itemStmt.run(order.lastInsertRowid,p.id,p.name,p.price,qty));
      return order.lastInsertRowid;
    });
    res.json({orderId:tx,reference,total,currency:process.env.PAYSTACK_CURRENCY||'NGN'});
  } catch { safeError(res); }
});

async function paystack(pathname, options={}) {
  const secret=getSecret('PAYSTACK_SECRET_KEY');
  if(!secret) throw new Error('Paystack is not configured');
  const response=await fetch('https://api.paystack.co'+pathname,{...options,headers:{'Authorization':`Bearer ${secret}`,'Content-Type':'application/json',...(options.headers||{})}});
  const data=await response.json().catch(()=>({}));
  if(!response.ok || !data.status) throw new Error(data.message||'Paystack request failed');
  return data;
}
app.post('/api/payments/initialize', originGuard, async (req,res)=>{
  try {
    const {reference,email}=req.body||{};
    const order=db.prepare('SELECT * FROM orders WHERE reference=?').get(reference);
    if(!order || order.email!==email) return res.status(404).json({error:'Order not found'});
    const result=await paystack('/transaction/initialize',{method:'POST',body:JSON.stringify({amount:String(order.total*100),email:order.email,currency:order.currency,reference:order.reference,callback_url:`${process.env.APP_URL||'http://localhost:4000'}/payment/callback?reference=${encodeURIComponent(order.reference)}`,metadata:{order_id:order.id}})});
    db.prepare('UPDATE orders SET paystack_reference=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(result.data.reference,order.id);
    res.json({authorization_url:result.data.authorization_url,access_code:result.data.access_code,reference:result.data.reference});
  } catch(e) { res.status(503).json({error:e.message==='Paystack is not configured'?'Payment is temporarily unavailable. Please contact us.':'Unable to start payment. Please try again.'}); }
});
app.get('/api/payments/verify/:reference', async (req,res)=>{
  try {
    const order=db.prepare('SELECT * FROM orders WHERE reference=? OR paystack_reference=?').get(req.params.reference,req.params.reference);
    if(!order) return res.status(404).json({error:'Order not found'});
    const result=await paystack('/transaction/verify/'+encodeURIComponent(req.params.reference));
    if(result.data?.status==='success' && Number(result.data.amount)===order.total*100) {
      db.prepare("UPDATE orders SET payment_status='Paid',order_status=CASE WHEN order_status='Pending' THEN 'Paid' ELSE order_status END,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(order.id);
      return res.json({ok:true,status:'Paid'});
    }
    res.json({ok:true,status:result.data?.status||'pending'});
  } catch { res.status(503).json({error:'Payment verification is temporarily unavailable.'}); }
});


app.get('/api/orders', auth, (req,res)=>{
  const orders=db.prepare('SELECT * FROM orders ORDER BY id DESC').all();
  const items=db.prepare('SELECT * FROM order_items').all();
  const by=new Map(); items.forEach(i=>(by.get(i.order_id)||by.set(i.order_id,[]).get(i.order_id)).push(i));
  res.json(orders.map(o=>({...o,items:by.get(o.id)||[]})));
});
app.patch('/api/orders/:id/status', auth, originGuard, (req,res)=>{
  const allowed=['Pending','Paid','Processing','Shipped','Delivered','Cancelled'];
  if(!allowed.includes(req.body?.status)) return res.status(400).json({error:'Invalid order status'});
  db.prepare('UPDATE orders SET order_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(req.body.status,req.params.id);
  res.json(db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id));
});

app.get('/api/settings', auth, (req,res)=>res.json(publicSettings()));
app.put('/api/settings', auth, originGuard, (req,res)=>{
  const allowed=['whatsapp','instagram','tiktok','facebook','pinterest','email','hero_title','hero_eyebrow','founder_title','founder_text','announcement'];
  const stmt=db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  for(const k of allowed) if(typeof req.body?.[k]==='string') stmt.run(k,req.body[k].slice(0,1000));
  res.json(publicSettings());
});
app.get('/api/secrets/status', auth, (req,res)=>{
  const keys=['PAYSTACK_SECRET_KEY','FACEBOOK_APP_ID','FACEBOOK_APP_SECRET','INSTAGRAM_APP_ID','INSTAGRAM_APP_SECRET','GOOGLE_CLIENT_ID','GOOGLE_CLIENT_SECRET','SMTP_HOST','SMTP_USER','SMTP_PASS'];
  res.json(Object.fromEntries(keys.map(k=>[k,Boolean(getSecret(k))])));
});
app.put('/api/secrets', auth, originGuard, (req,res)=>{
  const allowed=['PAYSTACK_SECRET_KEY','FACEBOOK_APP_ID','FACEBOOK_APP_SECRET','INSTAGRAM_APP_ID','INSTAGRAM_APP_SECRET','GOOGLE_CLIENT_ID','GOOGLE_CLIENT_SECRET','SMTP_HOST','SMTP_USER','SMTP_PASS','MAIL_FROM'];
  for(const k of allowed) if(typeof req.body?.[k]==='string' && req.body[k]) setSecret(k,req.body[k]);
  res.json({ok:true});
});

app.post('/api/messages', originGuard, (req,res)=>{
  const {name,email,phone,message}=req.body||{};
  if(!name||!email||!message) return res.status(400).json({error:'Name, email and message are required'});
  const r=db.prepare('INSERT INTO messages(name,email,phone,message) VALUES(?,?,?,?)').run(name,email,phone||'',message);
  res.json({ok:true,id:r.lastInsertRowid});
});
app.get('/api/messages', auth, (req,res)=>res.json(db.prepare('SELECT * FROM messages ORDER BY id DESC').all()));
app.patch('/api/messages/:id/read', auth, originGuard, (req,res)=>{db.prepare("UPDATE messages SET status='read' WHERE id=?").run(req.params.id);res.json({ok:true});});
app.post('/api/messages/:id/reply', auth, originGuard, async (req,res)=>{
  const row=db.prepare('SELECT * FROM messages WHERE id=?').get(req.params.id); if(!row)return res.status(404).json({error:'Message not found'});
  const smtpHost=getSecret('SMTP_HOST'); const smtpUser=getSecret('SMTP_USER'); const smtpPass=getSecret('SMTP_PASS'); const from=getSecret('MAIL_FROM')||smtpUser;
  if(!smtpHost||!smtpUser||!smtpPass) return res.status(503).json({error:'Email sending is not configured yet. Add SMTP secrets in Settings.'});
  try {
    const transporter=nodemailer.createTransport({host:smtpHost,port:Number(getSecret('SMTP_PORT')||587),secure:Number(getSecret('SMTP_PORT')||587)===465,auth:{user:smtpUser,pass:smtpPass}});
    await transporter.sendMail({from,to:row.email,subject:'Furbz Sparkle — Reply',text:String(req.body?.reply||'')});
    db.prepare("UPDATE messages SET reply=?,status='replied',replied_at=CURRENT_TIMESTAMP WHERE id=?").run(String(req.body?.reply||''),row.id);
    res.json({ok:true});
  } catch { safeError(res,503); }
});

// OAuth connector helpers. Tokens are stored server-side; actual provider app credentials must be supplied in Secrets.
function connector(name){return db.prepare('SELECT provider,account_name,external_id,expires_at,meta_json,updated_at FROM oauth_connections WHERE provider=?').get(name)||null;}
app.get('/api/connectors', auth, (req,res)=>res.json(['facebook','instagram','google'].map(provider=>({...({facebook:'Facebook Page',instagram:'Instagram Business',google:'Google Business Profile'}[provider]),provider,connection:connector(provider)}))));
app.get('/api/connectors/:provider/start', auth, (req,res)=>{
  const p=req.params.provider; const cfg={
    facebook:{id:getSecret('FACEBOOK_APP_ID'),redirect:process.env.FACEBOOK_REDIRECT_URI,scope:'pages_show_list,pages_read_engagement'},
    instagram:{id:getSecret('INSTAGRAM_APP_ID'),redirect:process.env.INSTAGRAM_REDIRECT_URI,scope:'instagram_business_basic,instagram_business_content_publish,instagram_business_manage_messages,instagram_business_manage_comments'},
    google:{id:getSecret('GOOGLE_CLIENT_ID'),redirect:process.env.GOOGLE_REDIRECT_URI,scope:'https://www.googleapis.com/auth/business.manage'}
  }[p];
  if(!cfg?.id||!cfg?.redirect) return res.status(503).json({error:`${p} connector is not configured. Add its OAuth credentials in Secrets first.`});
  const state=crypto.randomBytes(24).toString('hex');
  setSecret('OAUTH_STATE_'+p,state);
  const authUrl=p==='google'
    ? `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(cfg.id)}&redirect_uri=${encodeURIComponent(cfg.redirect)}&response_type=code&scope=${encodeURIComponent(cfg.scope)}&access_type=offline&prompt=consent&state=${state}`
    : `https://www.facebook.com/v24.0/dialog/oauth?client_id=${encodeURIComponent(cfg.id)}&redirect_uri=${encodeURIComponent(cfg.redirect)}&response_type=code&scope=${encodeURIComponent(cfg.scope)}&state=${state}`;
  res.json({url:authUrl});
});
async function oauthToken(p, code){
  const maps={facebook:{id:getSecret('FACEBOOK_APP_ID'),secret:getSecret('FACEBOOK_APP_SECRET'),redirect:process.env.FACEBOOK_REDIRECT_URI,url:'https://graph.facebook.com/v24.0/oauth/access_token'},instagram:{id:getSecret('INSTAGRAM_APP_ID'),secret:getSecret('INSTAGRAM_APP_SECRET'),redirect:process.env.INSTAGRAM_REDIRECT_URI,url:'https://graph.facebook.com/v24.0/oauth/access_token'},google:{id:getSecret('GOOGLE_CLIENT_ID'),secret:getSecret('GOOGLE_CLIENT_SECRET'),redirect:process.env.GOOGLE_REDIRECT_URI,url:'https://oauth2.googleapis.com/token'}};
  const m=maps[p]; const body=new URLSearchParams({client_id:m.id,client_secret:m.secret,redirect_uri:m.redirect,code});
  if(p==='google') body.set('grant_type','authorization_code');
  const r=await fetch(m.url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
  const d=await r.json(); if(!r.ok||d.error) throw new Error('OAuth exchange failed'); return d;
}
app.get('/api/connectors/:provider/callback', async (req,res)=>{
  const p=req.params.provider; try{
    if(req.query.state!==getSecret('OAUTH_STATE_'+p)) return res.status(400).send('Invalid OAuth state');
    const d=await oauthToken(p,req.query.code); const access=d.access_token; let accountName='Connected'; let externalId=''; let meta={};
    if(p==='google') { const r=await fetch('https://mybusinessaccountmanagement.googleapis.com/v1/accounts',{headers:{Authorization:`Bearer ${access}`}}); const j=await r.json(); accountName=j.accounts?.[0]?.accountName||'Google Business Profile'; externalId=j.accounts?.[0]?.name||''; meta=j; }
    else { const r=await fetch(`https://graph.facebook.com/v24.0/me?fields=id,name&access_token=${encodeURIComponent(access)}`); const j=await r.json(); accountName=j.name||p; externalId=j.id||''; meta=j; }
    db.prepare(`INSERT INTO oauth_connections(provider,account_name,external_id,access_token,refresh_token,expires_at,meta_json,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(provider) DO UPDATE SET account_name=excluded.account_name,external_id=excluded.external_id,access_token=excluded.access_token,refresh_token=excluded.refresh_token,expires_at=excluded.expires_at,meta_json=excluded.meta_json,updated_at=CURRENT_TIMESTAMP`).run(p,accountName,externalId,access,d.refresh_token||'',d.expires_in?new Date(Date.now()+d.expires_in*1000).toISOString():null,JSON.stringify(meta));
    res.send(`<html><body style="font-family:system-ui;padding:40px"><h2>${p} connected</h2><p>You can close this window and return to Furbz Sparkle.</p><script>window.opener&&window.opener.postMessage({connected:'${p}'},'*');setTimeout(()=>window.close(),1200)</script></body></html>`);
  } catch {res.status(500).send('Unable to connect this service. Check the connector credentials and try again.');}
});

app.get('/api/dashboard/summary', auth, (req,res)=>{
  const products=db.prepare('SELECT COUNT(*) c FROM products WHERE active=1').get().c;
  const orders=db.prepare('SELECT COUNT(*) c FROM orders').get().c;
  const pending=db.prepare("SELECT COUNT(*) c FROM orders WHERE order_status IN ('Pending','Paid')").get().c;
  const unread=db.prepare("SELECT COUNT(*) c FROM messages WHERE status='unread'").get().c;
  res.json({products,orders,pending,unread});
});

if (fs.existsSync(path.join(CLIENT_DIST,'index.html'))) {
  app.use(express.static(CLIENT_DIST));
  app.get(/.*/,(req,res)=>res.sendFile(path.join(CLIENT_DIST,'index.html')));
}

app.listen(PORT,()=>console.log(`Furbz Sparkle server running on http://localhost:${PORT}`));
